import React, { useEffect, useMemo, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import {
  Menu, X, Home, Users, Network, Layers, Search, ChevronRight, ArrowLeft,
  ShieldCheck, LogIn, LogOut, Plus, Pencil, Trash2, Upload, Save, XCircle,
  HeartHandshake, Instagram, Mail, Image as ImageIcon
} from 'lucide-react';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const POSITIONS = [
  'Pembina', 'Pelatih', 'Komandan', 'Wakil Komandan', 'Sekretaris', 'Bendahara',
  'Humas', 'Tata Tertib', 'Divisi UKS', 'Divisi Kesja', 'Divisi PDD', 'Divisi Danus'
];
const emptyMember = { full_name: '', class_name: '', position: '', division: '', generation_id: '', bio: '', sort_order: 0, photo_url: '' };

function Logo({ settings, small = false }) {
  return <div className={`brand-mark ${small ? 'small' : ''}`}>
    {settings?.logo_url
      ? <img src={settings.logo_url} alt="Logo PMR Respati" />
      : <span className="brand-cross">✚</span>}
    <span className="brand-word">RESPATI</span>
  </div>;
}
function Photo({ src, name }) {
  return src ? <img className="member-photo" src={src} alt={`Foto ${name}`} /> :
    <div className="member-photo photo-placeholder"><Users size={27} /></div>;
}

export default function App() {
  const [page, setPage] = useState('home');
  const [sidebar, setSidebar] = useState(false);
  const [members, setMembers] = useState([]);
  const [generations, setGenerations] = useState([]);
  const [settings, setSettings] = useState(null);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [divisionFilter, setDivisionFilter] = useState('');
  const [generationFilter, setGenerationFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);
  const [operator, setOperator] = useState(false);
  const [notice, setNotice] = useState('');
  const [configMissing, setConfigMissing] = useState(!supabase);
  const [editing, setEditing] = useState(null);
  const [memberForm, setMemberForm] = useState(emptyMember);
  const [generationForm, setGenerationForm] = useState({ name: '', period: '', sort_order: 0 });
  const [settingsForm, setSettingsForm] = useState({ description: '', logo_url: '' });
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    if (!supabase) { setLoading(false); return; }
    setLoading(true);
    const [m, g, s] = await Promise.all([
      supabase.from('members').select('*').order('sort_order').order('full_name'),
      supabase.from('generations').select('*').order('sort_order').order('name'),
      supabase.from('organization_settings').select('*').eq('id', 1).maybeSingle()
    ]);
    if (m.error || g.error || s.error) setNotice('Data belum dapat dimuat. Periksa konfigurasi database dan kebijakan akses Supabase.');
    setMembers(m.data || []); setGenerations(g.data || []);
    setSettings(s.data || { description: 'PMR Respati merupakan organisasi Palang Merah Remaja di SMA Pasundan 3 Cimahi.' });
    setSettingsForm({ description: s.data?.description || '', logo_url: s.data?.logo_url || '' });
    setLoading(false);
  };

  useEffect(() => {
    refresh();
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const check = async () => {
      if (!session || !supabase) { setOperator(false); return; }
      const { data } = await supabase.from('operator_profiles').select('user_id').eq('user_id', session.user.id).maybeSingle();
      setOperator(!!data);
    };
    check();
  }, [session]);

  useEffect(() => { if (notice) { const t = setTimeout(() => setNotice(''), 4200); return () => clearTimeout(t); } }, [notice]);

  const classes = useMemo(() => [...new Set(members.map(x => x.class_name).filter(Boolean))].sort(), [members]);
  const divisions = useMemo(() => [...new Set(members.map(x => x.division || x.position).filter(Boolean))].sort(), [members]);
  const filtered = useMemo(() => members.filter(m =>
    m.full_name.toLowerCase().includes(search.toLowerCase()) &&
    (!classFilter || m.class_name === classFilter) &&
    (!divisionFilter || (m.division || m.position) === divisionFilter) &&
    (!generationFilter || m.generation_id === generationFilter)
  ), [members, search, classFilter, divisionFilter, generationFilter]);

  const go = (next) => { setPage(next); setSelected(null); setSidebar(false); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const openProfile = (member) => { setSelected(member); setPage('profile'); setSidebar(false); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const uploadImage = async (file, folder) => {
    if (!file || !supabase) return null;
    if (!file.type.startsWith('image/')) throw new Error('File harus berupa gambar.');
    if (file.size > 5 * 1024 * 1024) throw new Error('Ukuran gambar maksimal 5 MB.');
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
    const path = `${folder}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from('respati-media').upload(path, file, { upsert: false, contentType: file.type });
    if (error) throw error;
    return supabase.storage.from('respati-media').getPublicUrl(path).data.publicUrl;
  };
  const saveMember = async (e) => {
    e.preventDefault(); if (!operator) return;
    setSaving(true);
    try {
      let payload = { ...memberForm, generation_id: memberForm.generation_id || null, updated_at: new Date().toISOString() };
      if (editing?.file) payload.photo_url = await uploadImage(editing.file, 'members');
      delete payload.file;
      const result = editing?.id
        ? await supabase.from('members').update(payload).eq('id', editing.id)
        : await supabase.from('members').insert(payload);
      if (result.error) throw result.error;
      setEditing(null); setMemberForm(emptyMember); setNotice('Data anggota berhasil disimpan.'); await refresh();
    } catch (err) { setNotice(err.message || 'Gagal menyimpan data.'); }
    setSaving(false);
  };
  const startEdit = (m = null) => {
    setEditing(m ? { id: m.id, file: null } : { id: null, file: null });
    setMemberForm(m ? { ...emptyMember, ...m, generation_id: m.generation_id || '' } : { ...emptyMember, sort_order: members.length + 1 });
    go('admin'); setAdminTab('members');
  };
  const deleteMember = async (m) => {
    if (!operator || !window.confirm(`Hapus data ${m.full_name}? Tindakan ini tidak dapat dibatalkan.`)) return;
    const { error } = await supabase.from('members').delete().eq('id', m.id);
    setNotice(error ? error.message : 'Data anggota dihapus.'); if (!error) await refresh();
  };
  const [adminTab, setAdminTab] = useState('members');
  const login = async (e) => {
    e.preventDefault();
    const { error } = await supabase.auth.signInWithPassword(loginForm);
    if (error) setNotice('Login gagal. Periksa email dan kata sandi operator.');
    else { setNotice('Login berhasil.'); setLoginForm({ email: '', password: '' }); }
  };
  const logout = async () => { await supabase.auth.signOut(); setOperator(false); go('home'); setNotice('Anda telah keluar.'); };
  const saveGeneration = async (e) => {
    e.preventDefault(); if (!operator) return;
    const { error } = generationForm.id
      ? await supabase.from('generations').update(generationForm).eq('id', generationForm.id)
      : await supabase.from('generations').insert(generationForm);
    setNotice(error ? error.message : 'Data angkatan disimpan.');
    setGenerationForm({ name: '', period: '', sort_order: generations.length + 1 });
    if (!error) await refresh();
  };
  const removeGeneration = async (g) => {
    if (!window.confirm(`Hapus ${g.name}? Anggota terkait akan menjadi tanpa angkatan.`)) return;
    const { error } = await supabase.from('generations').delete().eq('id', g.id);
    setNotice(error ? error.message : 'Angkatan dihapus.'); if (!error) await refresh();
  };
  const saveSettings = async (e) => {
    e.preventDefault(); if (!operator) return;
    setSaving(true);
    try {
      let logo_url = settingsForm.logo_url;
      if (editing?.logoFile) logo_url = await uploadImage(editing.logoFile, 'branding');
      const { error } = await supabase.from('organization_settings').update({ description: settingsForm.description, logo_url, updated_at: new Date().toISOString() }).eq('id', 1);
      if (error) throw error;
      setNotice('Identitas organisasi diperbarui.'); setEditing(null); await refresh();
    } catch (err) { setNotice(err.message); }
    setSaving(false);
  };

  const navItems = [
    ['home', 'Beranda', Home], ['structure', 'Struktur Organisasi', Network],
    ['members', 'Seluruh Anggota', Users], ['generations', 'Data Angkatan', Layers]
  ];
  const goAdmin = () => { go('admin'); setAdminTab('members'); };

  return <div className="app-shell">
    <header className="topbar">
      <button className="icon-button hamburger" aria-label="Buka menu" onClick={() => setSidebar(true)}><Menu /></button>
      <button className="brand-button" onClick={() => go('home')}><Logo settings={settings} small /></button>
      <nav className="desktop-nav">{navItems.map(([id, label]) => <button key={id} className={page === id ? 'active' : ''} onClick={() => go(id)}>{label}</button>)}</nav>
      <button className="operator-link" onClick={goAdmin}><ShieldCheck size={16} /> Operator</button>
    </header>

    <div className={`sidebar-backdrop ${sidebar ? 'show' : ''}`} onClick={() => setSidebar(false)} />
    <aside className={`sidebar ${sidebar ? 'open' : ''}`}>
      <div className="sidebar-head"><Logo settings={settings} /><button className="icon-button light" onClick={() => setSidebar(false)} aria-label="Tutup menu"><X /></button></div>
      <p className="sidebar-label">MENU UTAMA</p>
      {navItems.map(([id, label, Icon]) => <button key={id} className={`side-link ${page === id ? 'selected' : ''}`} onClick={() => go(id)}><Icon size={19} />{label}<ChevronRight size={16} /></button>)}
      <div className="sidebar-bottom"><span>PMR RESPATI</span><small>SMA Pasundan 3 Cimahi</small></div>
    </aside>

    {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice('')}><X size={15}/></button></div>}
    {configMissing && <div className="setup-alert">Website belum terhubung ke Supabase. Ikuti panduan konfigurasi pada README sebelum digunakan secara publik.</div>}

    <main>
      {loading && <div className="loading-state">Memuat data PMR Respati...</div>}

      {!loading && page === 'home' && <div className="page-enter">
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow"><span className="eyebrow-dot" /> ORGANISASI KEMANUSIAAN SEKOLAH</span>
            <h1>PMR <em>RESPATI</em></h1>
            <p className="school-name">SMA PASUNDAN 3 CIMAHI</p>
            <p className="hero-motto">“Bergerak dalam kepedulian, tumbuh dalam kemanusiaan.”</p>
            <p className="hero-description">{settings?.description}</p>
            <div className="hero-actions">
              <button className="btn-primary" onClick={() => go('structure')}>Lihat Struktur <ChevronRight size={17}/></button>
              <button className="btn-outline" onClick={() => go('members')}>Direktori Anggota</button>
            </div>
          </div>
          <div className="hero-art">
            <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
            <div className="hero-emblem"><span>✚</span><b>RESPATI</b><small>CARE · SERVE · INSPIRE</small></div>
            <div className="floating-note"><HeartHandshake size={18}/><span><b>Peduli sesama</b><small>Beraksi dengan empati</small></span></div>
            <div className="hero-number"><strong>{members.length.toString().padStart(2, '0')}</strong><small>ANGGOTA TERCATAT</small></div>
          </div>
        </section>
        <section className="intro-section">
          <div><span className="section-kicker">TENTANG KAMI</span><h2>Belajar peduli,<br/><em>bertumbuh bersama.</em></h2></div>
          <p>PMR Respati menjadi wadah bagi siswa untuk mengembangkan pengetahuan, keterampilan, kepemimpinan, dan semangat kemanusiaan melalui kegiatan Palang Merah Remaja.</p>
        </section>
        <section className="quick-grid">
          <button className="quick-card" onClick={() => go('structure')}><span className="quick-icon"><Network/></span><span><b>Struktur Organisasi</b><small>Kenali susunan kepengurusan PMR Respati.</small></span><ChevronRight/></button>
          <button className="quick-card" onClick={() => go('members')}><span className="quick-icon red"><Users/></span><span><b>Direktori Anggota</b><small>Temukan profil anggota PMR Respati.</small></span><ChevronRight/></button>
          <button className="quick-card" onClick={() => go('generations')}><span className="quick-icon"><Layers/></span><span><b>Data Angkatan</b><small>Lihat perjalanan anggota dari setiap angkatan.</small></span><ChevronRight/></button>
        </section>
      </div>}

      {!loading && page === 'structure' && <section className="content-page page-enter">
        <PageHeading kicker="KEPENGURUSAN" title="Struktur Organisasi" subtitle="Susunan kepengurusan PMR Respati SMA Pasundan 3 Cimahi." />
        <div className="org-tree">
          {POSITIONS.map((position, index) => {
            const people = members.filter(m => m.position === position).sort((a,b) => a.sort_order-b.sort_order);
            return <div className={`org-level level-${index}`} key={position}>
              <div className="org-label"><span>{String(index + 1).padStart(2, '0')}</span>{position}</div>
              <div className="org-cards">{people.length ? people.map(m => <MemberCard key={m.id} member={m} onClick={() => openProfile(m)} />) : <div className="empty-position">Belum ada data untuk jabatan ini</div>}</div>
            </div>;
          })}
        </div>
      </section>}

      {!loading && page === 'members' && <section className="content-page page-enter">
        <PageHeading kicker="DIREKTORI" title="Seluruh Anggota" subtitle="Kenali keluarga besar PMR Respati." />
        <div className="filter-bar">
          <div className="search-box"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari nama anggota..." /></div>
          <select value={classFilter} onChange={e => setClassFilter(e.target.value)}><option value="">Semua kelas</option>{classes.map(x => <option key={x}>{x}</option>)}</select>
          <select value={divisionFilter} onChange={e => setDivisionFilter(e.target.value)}><option value="">Semua jabatan/divisi</option>{divisions.map(x => <option key={x}>{x}</option>)}</select>
          <span className="result-count">{filtered.length} anggota</span>
        </div>
        {filtered.length ? <div className="member-grid">{filtered.map(m => <MemberCard key={m.id} member={m} onClick={() => openProfile(m)} />)}</div> : <EmptyState title="Anggota tidak ditemukan" text="Coba ubah kata kunci atau filter pencarian." />}
      </section>}

      {!loading && page === 'profile' && selected && <section className="content-page profile-page page-enter">
        <button className="back-link" onClick={() => go('members')}><ArrowLeft size={17}/> Kembali ke direktori</button>
        <div className="profile-panel"><div className="profile-photo-wrap"><Photo src={selected.photo_url} name={selected.full_name}/><span className="profile-accent"/></div>
          <div className="profile-info"><span className="section-kicker">PROFIL ANGGOTA</span><h1>{selected.full_name}</h1>
            <div className="profile-tags">{selected.class_name && <span>{selected.class_name}</span>}{selected.position && <span>{selected.position}</span>}{selected.division && <span>{selected.division}</span>}</div>
            {selected.bio && <div className="bio-block"><h3>Tentang</h3><p>{selected.bio}</p></div>}
            {generations.find(g => g.id === selected.generation_id) && <p className="profile-generation">Bagian dari {generations.find(g => g.id === selected.generation_id).name}</p>}
          </div>
        </div>
      </section>}

      {!loading && page === 'generations' && <section className="content-page page-enter">
        <PageHeading kicker="PERJALANAN KAMI" title="Data Angkatan" subtitle="Kenali anggota PMR Respati berdasarkan angkatan." />
        {generations.length ? <div className="generation-grid">{generations.map(g => {
          const count = members.filter(m => m.generation_id === g.id).length;
          return <button className="generation-card" key={g.id} onClick={() => { setGenerationFilter(g.id); go('generation-detail'); }}>
            <span className="generation-icon"><Layers/></span><span className="generation-name">{g.name}</span>
            {g.period && <small>{g.period}</small>}<span className="generation-count">{count} anggota</span><ChevronRight className="generation-arrow"/>
          </button>;
        })}</div> : <EmptyState title="Data angkatan belum tersedia" text="Informasi angkatan akan ditampilkan setelah ditambahkan oleh operator."/>}
      </section>}

      {!loading && page === 'generation-detail' && <section className="content-page page-enter">
        <button className="back-link" onClick={() => go('generations')}><ArrowLeft size={17}/> Kembali ke data angkatan</button>
        <PageHeading kicker="DATA ANGKATAN" title={generations.find(g => g.id === generationFilter)?.name || 'Angkatan'} subtitle="Daftar anggota dalam angkatan ini." />
        <div className="member-grid">{members.filter(m => m.generation_id === generationFilter).map(m => <MemberCard key={m.id} member={m} onClick={() => openProfile(m)}/>)}</div>
        {!members.some(m => m.generation_id === generationFilter) && <EmptyState title="Belum ada anggota" text="Belum ada anggota yang terhubung dengan angkatan ini."/>}
      </section>}

      {!loading && page === 'admin' && <section className="content-page admin-page page-enter">
        {!session ? <div className="login-card"><div className="login-symbol"><ShieldCheck/></div><span className="section-kicker">AREA TERBATAS</span><h1>Login Operator</h1><p>Masuk menggunakan akun operator PMR Respati yang telah didaftarkan.</p>
          <form onSubmit={login} className="stack-form"><label>Email operator<input type="email" required value={loginForm.email} onChange={e => setLoginForm({...loginForm,email:e.target.value})} placeholder="operator@email.com"/></label><label>Kata sandi<input type="password" required value={loginForm.password} onChange={e => setLoginForm({...loginForm,password:e.target.value})} placeholder="Masukkan kata sandi"/></label><button className="btn-primary full" type="submit"><LogIn size={17}/> Masuk</button></form>
          <small className="secure-note"><ShieldCheck size={14}/> Akses dikelola melalui autentikasi Supabase.</small>
        </div> : !operator ? <div className="login-card"><div className="login-symbol"><ShieldCheck/></div><h1>Akses belum diberikan</h1><p>Akun berhasil masuk, tetapi belum terdaftar sebagai operator PMR Respati. Hubungi administrator website.</p><button className="btn-outline" onClick={logout}><LogOut size={16}/> Keluar</button></div> :
        <><div className="admin-heading"><div><span className="section-kicker">PANEL PENGELOLAAN</span><h1>Dashboard Operator</h1><p>Kelola direktori, angkatan, dan identitas organisasi.</p></div><button className="btn-outline" onClick={logout}><LogOut size={16}/> Keluar</button></div>
          <div className="admin-tabs"><button className={adminTab==='members'?'chosen':''} onClick={() => setAdminTab('members')}>Anggota</button><button className={adminTab==='generations'?'chosen':''} onClick={() => setAdminTab('generations')}>Angkatan</button><button className={adminTab==='settings'?'chosen':''} onClick={() => setAdminTab('settings')}>Identitas</button></div>
          {adminTab === 'members' && <div className="admin-section">
            <div className="admin-section-head"><div><h2>Data Anggota</h2><p>{members.length} data anggota tersimpan</p></div><button className="btn-primary" onClick={() => startEdit()}><Plus size={17}/> Tambah Anggota</button></div>
            {editing && <form className="editor-form" onSubmit={saveMember}>
              <h3>{editing.id ? 'Edit Anggota' : 'Tambah Anggota'}</h3>
              <div className="form-grid">
                <label>Nama lengkap *<input required value={memberForm.full_name} onChange={e=>setMemberForm({...memberForm,full_name:e.target.value})}/></label>
                <label>Kelas<input value={memberForm.class_name||''} onChange={e=>setMemberForm({...memberForm,class_name:e.target.value})} placeholder="Contoh: XII IPS 1"/></label>
                <label>Jabatan<select value={memberForm.position||''} onChange={e=>setMemberForm({...memberForm,position:e.target.value})}><option value="">Pilih jabatan</option>{POSITIONS.map(p=><option key={p}>{p}</option>)}</select></label>
                <label>Divisi<input value={memberForm.division||''} onChange={e=>setMemberForm({...memberForm,division:e.target.value})} placeholder="Opsional"/></label>
                <label>Angkatan<select value={memberForm.generation_id||''} onChange={e=>setMemberForm({...memberForm,generation_id:e.target.value})}><option value="">Tanpa angkatan</option>{generations.map(g=><option value={g.id} key={g.id}>{g.name}</option>)}</select></label>
                <label>Urutan tampil<input type="number" value={memberForm.sort_order??0} onChange={e=>setMemberForm({...memberForm,sort_order:Number(e.target.value)})}/></label>
                <label className="wide">Foto anggota<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setEditing({...editing,file:e.target.files?.[0]||null})}/><small>Maksimal 5 MB. {memberForm.photo_url && !editing.file ? 'Foto saat ini tersimpan.' : ''}</small></label>
                <label className="wide">Deskripsi singkat<textarea rows="3" value={memberForm.bio||''} onChange={e=>setMemberForm({...memberForm,bio:e.target.value})}/></label>
              </div>
              <div className="form-actions"><button className="btn-primary" disabled={saving}><Save size={16}/> {saving?'Menyimpan...':'Simpan Perubahan'}</button><button type="button" className="btn-outline" onClick={()=>{setEditing(null);setMemberForm(emptyMember)}}>Batal</button></div>
            </form>}
            <div className="admin-table">{members.map(m=><div className="admin-row" key={m.id}><Photo src={m.photo_url} name={m.full_name}/><div className="admin-row-name"><b>{m.full_name}</b><small>{m.class_name||'Kelas belum diisi'} · {m.position||'Jabatan belum diisi'}</small></div><button className="table-action" title="Edit" onClick={()=>startEdit(m)}><Pencil size={17}/></button><button className="table-action danger" title="Hapus" onClick={()=>deleteMember(m)}><Trash2 size={17}/></button></div>)}</div>
          </div>}
          {adminTab === 'generations' && <div className="admin-section"><div className="admin-section-head"><div><h2>Kelola Angkatan</h2><p>Buat dan atur daftar angkatan PMR Respati.</p></div></div>
            <form className="editor-form" onSubmit={saveGeneration}><h3>{generationForm.id?'Edit Angkatan':'Tambah Angkatan'}</h3><div className="form-grid">
              <label>Nama angkatan *<input required value={generationForm.name} onChange={e=>setGenerationForm({...generationForm,name:e.target.value})} placeholder="Contoh: Angkatan 6"/></label>
              <label>Tahun/periode<input value={generationForm.period} onChange={e=>setGenerationForm({...generationForm,period:e.target.value})} placeholder="Contoh: 2025–2026"/></label>
              <label>Urutan tampil<input type="number" value={generationForm.sort_order} onChange={e=>setGenerationForm({...generationForm,sort_order:Number(e.target.value)})}/></label>
            </div><div className="form-actions"><button className="btn-primary"><Save size={16}/> Simpan Angkatan</button><button type="button" className="btn-outline" onClick={()=>setGenerationForm({name:'',period:'',sort_order:generations.length+1})}>Batal</button></div></form>
            <div className="admin-table">{generations.map(g=><div className="admin-row generation-admin-row" key={g.id}><div className="generation-icon compact"><Layers/></div><div className="admin-row-name"><b>{g.name}</b><small>{g.period||'Periode belum diisi'} · {members.filter(m=>m.generation_id===g.id).length} anggota</small></div><button className="table-action" title="Edit" onClick={()=>setGenerationForm(g)}><Pencil size={17}/></button><button className="table-action danger" title="Hapus" onClick={()=>removeGeneration(g)}><Trash2 size={17}/></button></div>)}</div>
          </div>}
          {adminTab === 'settings' && <div className="admin-section"><div className="admin-section-head"><div><h2>Identitas Organisasi</h2><p>Perbarui deskripsi dan logo PMR Respati.</p></div></div>
            <form className="editor-form" onSubmit={saveSettings}><label>Deskripsi organisasi<textarea rows="5" value={settingsForm.description} onChange={e=>setSettingsForm({...settingsForm,description:e.target.value})}/></label>
              <label>Ganti logo organisasi<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setEditing({logoFile:e.target.files?.[0]||null})}/><small>Logo akan tampil di bagian navigasi dan footer. Maksimal 5 MB.</small></label>
              {settings?.logo_url && <img className="logo-preview" src={settings.logo_url} alt="Logo saat ini"/>}
              <div className="form-actions"><button className="btn-primary" disabled={saving}><Save size={16}/> Simpan Perubahan</button></div>
            </form>
          </div>}
        </>}
      </section>}
    </main>

    <footer className="footer"><div className="footer-main"><Logo settings={settings}/><div><b>SMA Pasundan 3 Cimahi</b><p>PMR Respati — Bergerak dalam Kepedulian, Tumbuh dalam Kemanusiaan.</p></div><button className="footer-top" onClick={()=>window.scrollTo({top:0,behavior:'smooth'})}>Kembali ke atas ↑</button></div><div className="footer-bottom"><span>© {new Date().getFullYear()} PMR Respati</span><span>Palang Merah Remaja · SMA Pasundan 3 Cimahi</span></div></footer>
  </div>;
}

function PageHeading({ kicker, title, subtitle }) {
  return <div className="page-heading"><span className="section-kicker">{kicker}</span><h1>{title}</h1><p>{subtitle}</p></div>;
}
function MemberCard({ member, onClick }) {
  return <button className="member-card" onClick={onClick}>
    <div className="member-image"><Photo src={member.photo_url} name={member.full_name}/><span className="card-view">Lihat profil <ChevronRight size={14}/></span></div>
    <div className="member-card-info"><b>{member.full_name}</b><span>{member.class_name || 'Kelas belum diisi'}</span>{member.position && <small>{member.position}</small>}</div>
  </button>;
}
function EmptyState({ title, text }) {
  return <div className="empty-state"><div><Users size={25}/></div><h3>{title}</h3><p>{text}</p></div>;
}
