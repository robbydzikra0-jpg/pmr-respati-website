-- Jalankan seluruh SQL ini di Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.operator_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'operator' check (role in ('operator'))
);

create or replace function public.is_operator()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.operator_profiles
    where user_id = auth.uid() and role = 'operator'
  );
$$;

create table if not exists public.generations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  period text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  class_name text,
  position text,
  division text,
  generation_id uuid references public.generations(id) on delete set null,
  photo_url text,
  bio text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.organization_settings (
  id integer primary key default 1 check (id = 1),
  description text not null default 'PMR Respati merupakan organisasi Palang Merah Remaja di SMA Pasundan 3 Cimahi yang menjadi ruang belajar, berorganisasi, dan mengembangkan kepedulian kemanusiaan.',
  logo_url text,
  updated_at timestamptz not null default now()
);
insert into public.organization_settings (id) values (1) on conflict (id) do nothing;

alter table public.operator_profiles enable row level security;
alter table public.generations enable row level security;
alter table public.members enable row level security;
alter table public.organization_settings enable row level security;

create policy "Operator can read own operator profile"
on public.operator_profiles for select to authenticated
using (user_id = auth.uid());

create policy "Public can read generations"
on public.generations for select to anon, authenticated using (true);
create policy "Operator manages generations"
on public.generations for all to authenticated
using (public.is_operator()) with check (public.is_operator());

create policy "Public can read members"
on public.members for select to anon, authenticated using (true);
create policy "Operator manages members"
on public.members for all to authenticated
using (public.is_operator()) with check (public.is_operator());

create policy "Public can read organization settings"
on public.organization_settings for select to anon, authenticated using (true);
create policy "Operator updates organization settings"
on public.organization_settings for update to authenticated
using (public.is_operator()) with check (public.is_operator());

-- Bucket publik untuk foto profil dan logo. Upload/update/delete tetap khusus operator.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('respati-media', 'respati-media', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "Anyone can view Respati media"
on storage.objects for select to anon, authenticated
using (bucket_id = 'respati-media');

create policy "Operator can upload Respati media"
on storage.objects for insert to authenticated
with check (bucket_id = 'respati-media' and public.is_operator());

create policy "Operator can update Respati media"
on storage.objects for update to authenticated
using (bucket_id = 'respati-media' and public.is_operator())
with check (bucket_id = 'respati-media' and public.is_operator());

create policy "Operator can delete Respati media"
on storage.objects for delete to authenticated
using (bucket_id = 'respati-media' and public.is_operator());

-- Setelah membuat akun melalui Supabase Authentication > Users,
-- jalankan SQL berikut dengan UUID akun operator yang benar:
-- insert into public.operator_profiles (user_id, role)
-- values ('UUID-AKUN-OPERATOR', 'operator')
-- on conflict (user_id) do update set role = excluded.role;
