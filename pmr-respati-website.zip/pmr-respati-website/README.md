# PMR Respati — Website Organisasi

Website direktori publik PMR Respati SMA Pasundan 3 Cimahi dengan panel operator, database Supabase, autentikasi, unggah foto, pengelolaan anggota, struktur organisasi, dan data angkatan.

## Teknologi
- React + Vite
- Supabase Auth, PostgreSQL Database, dan Storage
- Row Level Security (RLS): publik hanya membaca; akun yang terdaftar sebagai operator dapat mengelola data.

## 1. Menyiapkan Supabase
1. Buat proyek di https://supabase.com/.
2. Buka **SQL Editor**, lalu jalankan seluruh isi `supabase/schema.sql`.
3. Buka **Project Settings → API**. Salin Project URL dan `anon`/publishable key.
4. Salin `.env.example` menjadi `.env` di folder proyek, lalu isi:
   ```
   VITE_SUPABASE_URL=https://....supabase.co
   VITE_SUPABASE_ANON_KEY=....
   ```
   Kunci anon/publishable memang digunakan di frontend dan diamankan oleh RLS. **Jangan pernah memasukkan service_role key ke frontend.**

## 2. Membuat akun operator
1. Di Supabase, buka **Authentication → Users → Add user**.
2. Buat akun operator menggunakan email yang dikelola organisasi dan kata sandi kuat.
3. Salin UUID user tersebut.
4. Di SQL Editor, jalankan (ganti UUID dengan UUID akun operator):
   ```sql
   insert into public.operator_profiles (user_id, role)
   values ('UUID-AKUN-OPERATOR', 'operator')
   on conflict (user_id) do update set role = excluded.role;
   ```
5. Pendaftaran operator tidak tersedia dari website publik. Hanya admin proyek yang dapat memberi role operator.

## 3. Menjalankan secara lokal
Pastikan Node.js versi 18 atau lebih baru telah terpasang.
```bash
npm install
npm run dev
```
Buka alamat lokal yang ditampilkan Vite.

## 4. Deploy agar dapat diakses publik
Cara mudah: deploy ke Vercel atau Netlify.
1. Unggah folder proyek ini ke repository GitHub.
2. Impor repository ke Vercel/Netlify.
3. Tambahkan environment variables `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` pada pengaturan proyek hosting.
4. Jalankan build command `npm run build` dan output directory `dist`.
5. Deploy. Link hosting tersebut menjadi link publik website.

## 5. Mengelola website
- Pengunjung dapat membuka Beranda, Struktur Organisasi, Seluruh Anggota, profil anggota, dan Data Angkatan.
- Operator masuk melalui tombol **Operator**.
- Di panel operator, tab **Anggota** untuk tambah/edit/hapus anggota dan unggah foto.
- Tab **Angkatan** untuk menambah, mengubah, menghapus angkatan. Anggota dapat ditautkan ke angkatan melalui form anggota.
- Tab **Identitas** untuk mengganti deskripsi dan logo.
- Struktur organisasi selalu mengikuti urutan tetap di aplikasi: Pembina, Pelatih, Komandan, Wakil Komandan, Sekretaris, Bendahara, Humas, Tata Tertib, Divisi UKS, Divisi Kesja, Divisi PDD, Divisi Danus. Urutan kartu dalam tiap jabatan mengikuti nilai `sort_order`.

## Catatan keamanan dan operasional
- Foto publik menggunakan bucket `respati-media`; hanya operator yang dapat upload, update, dan delete.
- Jangan membagikan akun operator. Buat akun terpisah untuk setiap pengelola tepercaya.
- Aktifkan verifikasi email dan kebijakan kata sandi yang kuat di Supabase Auth.
- Data anggota dan foto adalah informasi pribadi. Dapatkan persetujuan anggota/wali yang diperlukan sebelum memublikasikan nama, kelas, dan foto, terutama jika anggota masih di bawah umur.
- Sebelum dipakai, uji semua alur dengan akun operator dan jendela browser tanpa login.
- Komponen struktur hanya menampilkan jabatan yang ada pada daftar tetap; jabatan yang belum memiliki anggota ditandai belum ada data.
